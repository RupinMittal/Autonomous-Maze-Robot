/*
 * systick.c
 *
 *  Created on: Sep 26, 2020
 *      Author: Tyler Price
 */

#ifndef INC_SYSTICK_H_
#define INC_SYSTICK_H_

#include "main.h"

void SysTick_Function(void);

#endif /* INC_SYSTICK_H_ */
